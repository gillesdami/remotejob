# RemoteJob

## Build

docker build . -t remotejobslave